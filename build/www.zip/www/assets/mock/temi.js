let temi = [{ 'ocCodTemaSintetico': 4 },
{ 'ocCodTemaSintetico': 5 },
{ 'ocCodTemaSintetico': 6 },
    { 'ocCodTemaSintetico': 7 }];
export default temi;