let categorie = [
    { 'ocCodTemaSintetico': 4, 'ocCodCategoriaSpesa': 9 },
    { 'ocCodTemaSintetico': 4, 'ocCodCategoriaSpesa': 10 },
    { 'ocCodTemaSintetico': 4, 'ocCodCategoriaSpesa': 11 },
    { 'ocCodTemaSintetico': 4, 'ocCodCategoriaSpesa': 12 },
    { 'ocCodTemaSintetico': 4, 'ocCodCategoriaSpesa': 13 },
    { 'ocCodTemaSintetico': 4, 'ocCodCategoriaSpesa': 14 },
    { 'ocCodTemaSintetico': 4, 'ocCodCategoriaSpesa': 15 },
    { 'ocCodTemaSintetico': 4, 'ocCodCategoriaSpesa': 16 },
    { 'ocCodTemaSintetico': 4, 'ocCodCategoriaSpesa': 68 },
    { 'ocCodTemaSintetico': 4, 'ocCodCategoriaSpesa': 70 },

    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 17 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 18 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 19 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 20 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 21 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 22 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 23 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 84 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 85 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 86 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 87 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 88 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 89 },
    { 'ocCodTemaSintetico': 5, 'ocCodCategoriaSpesa': 90 },

    { 'ocCodTemaSintetico': 6, 'ocCodCategoriaSpesa': 91 },
    { 'ocCodTemaSintetico': 6, 'ocCodCategoriaSpesa': 92 },
    { 'ocCodTemaSintetico': 6, 'ocCodCategoriaSpesa': 93 },
    { 'ocCodTemaSintetico': 6, 'ocCodCategoriaSpesa': 94 },
    { 'ocCodTemaSintetico': 6, 'ocCodCategoriaSpesa': 95 },

    { 'ocCodTemaSintetico': 7, 'ocCodCategoriaSpesa': 43 },
    { 'ocCodTemaSintetico': 7, 'ocCodCategoriaSpesa': 44 },
];

export default categorie;